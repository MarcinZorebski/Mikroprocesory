/**************************************************************
 * This file is a part of the PWM Demo (C).                   *
 **************************************************************/
/**
 * @file main.c
 * @author Koryciak
 * @date Nov 2020 
 * @brief File containing the main function. 
 * @ver 0.5
 */
 
#include "frdm_bsp.h" 
#include "tpm.h" 
#include "ws2812.h"




int main (void) { 

TPM0_Init_OC();
	for(int i=0;i<64;i++)
	{
	setLed(i,0x00,0x00,0xFF);
	}	
	NVIC_SetPriority(TPM0_IRQn, 2);
NVIC_ClearPendingIRQ(TPM0_IRQn);
NVIC_EnableIRQ(TPM0_IRQn);
  while(1) {
__NOP();															/* sleep & wait for interrupt */
	}
}
